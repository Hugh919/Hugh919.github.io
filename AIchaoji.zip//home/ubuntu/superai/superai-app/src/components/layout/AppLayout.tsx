import React from 'react';
import Sidebar from './Sidebar';
import CreationManagementSidebar from './CreationManagementSidebar';
import MainContent from './MainContent';

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  return (
    <div className="flex h-screen overflow-hidden bg-black text-white">
      {/* 左侧导航栏 */}
      <Sidebar />
      
      {/* 中间内容区 */}
      <MainContent>
        {children}
      </MainContent>
      
      {/* 右侧创作管理栏 */}
      <CreationManagementSidebar />
    </div>
  );
};

export default AppLayout;
