'use client';

import React, { useState } from 'react';

// 模拟历史对话数据
const mockChatHistory = [
  { id: 'chat1', title: '关于人工智能的讨论', date: '2025-03-18', preview: '人工智能是计算机科学的一个分支...' },
  { id: 'chat2', title: '网站开发建议', date: '2025-03-15', preview: '对于现代网站开发，我建议使用React或Next.js...' },
  { id: 'chat3', title: '数据分析方法', date: '2025-03-10', preview: '数据分析的第一步是数据清洗...' },
  { id: 'chat4', title: '学习资源推荐', date: '2025-03-05', preview: '以下是一些学习编程的优质资源...' },
  { id: 'chat5', title: '项目管理技巧', date: '2025-03-01', preview: '有效的项目管理需要明确的目标和计划...' },
];

// 模拟图片历史数据
const mockImageHistory = [
  { id: 'img1', title: '未来城市', date: '2025-03-17', url: 'https://picsum.photos/seed/img1/300/300' },
  { id: 'img2', title: '太空探索', date: '2025-03-14', url: 'https://picsum.photos/seed/img2/300/300' },
  { id: 'img3', title: '海底世界', date: '2025-03-12', url: 'https://picsum.photos/seed/img3/300/300' },
  { id: 'img4', title: '山川风景', date: '2025-03-08', url: 'https://picsum.photos/seed/img4/300/300' },
  { id: 'img5', title: '科技概念', date: '2025-03-03', url: 'https://picsum.photos/seed/img5/300/300' },
];

// 模拟视频历史数据
const mockVideoHistory = [
  { id: 'vid1', title: '科技演示', date: '2025-03-16', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', thumbnail: 'https://picsum.photos/seed/vid1/300/200' },
  { id: 'vid2', title: '产品介绍', date: '2025-03-13', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', thumbnail: 'https://picsum.photos/seed/vid2/300/200' },
  { id: 'vid3', title: '自然风光', date: '2025-03-09', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', thumbnail: 'https://picsum.photos/seed/vid3/300/200' },
];

type CreationType = 'chat' | 'image' | 'video';

const ChatHistoryItem = ({ item, onSelect }: { item: any, onSelect: () => void }) => (
  <div 
    className="p-3 border-b border-gray-800 hover:bg-gray-800/50 cursor-pointer transition-colors"
    onClick={onSelect}
  >
    <div className="flex justify-between items-start mb-1">
      <h3 className="font-medium text-white">{item.title}</h3>
      <span className="text-xs text-gray-500">{item.date}</span>
    </div>
    <p className="text-sm text-gray-400 truncate">{item.preview}</p>
  </div>
);

const ImageHistoryItem = ({ item, onSelect }: { item: any, onSelect: () => void }) => (
  <div 
    className="p-3 border-b border-gray-800 hover:bg-gray-800/50 cursor-pointer transition-colors"
    onClick={onSelect}
  >
    <div className="flex space-x-3">
      <div className="w-16 h-16 rounded overflow-hidden flex-shrink-0">
        <img src={item.url} alt={item.title} className="w-full h-full object-cover" />
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-medium text-white">{item.title}</h3>
          <span className="text-xs text-gray-500">{item.date}</span>
        </div>
        <div className="flex space-x-2 mt-2">
          <button className="px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs text-white transition-colors">
            下载
          </button>
          <button className="px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs text-white transition-colors">
            分享
          </button>
        </div>
      </div>
    </div>
  </div>
);

const VideoHistoryItem = ({ item, onSelect }: { item: any, onSelect: () => void }) => (
  <div 
    className="p-3 border-b border-gray-800 hover:bg-gray-800/50 cursor-pointer transition-colors"
    onClick={onSelect}
  >
    <div className="flex space-x-3">
      <div className="w-24 h-16 rounded overflow-hidden flex-shrink-0 relative">
        <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white opacity-80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-medium text-white">{item.title}</h3>
          <span className="text-xs text-gray-500">{item.date}</span>
        </div>
        <div className="flex space-x-2 mt-2">
          <button className="px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs text-white transition-colors">
            下载
          </button>
          <button className="px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs text-white transition-colors">
            分享
          </button>
        </div>
      </div>
    </div>
  </div>
);

const CreationManagement = () => {
  const [activeType, setActiveType] = useState<CreationType>('chat');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedItem, setSelectedItem] = useState<any>(null);
  
  // 根据类型获取数据
  const getDataByType = () => {
    switch (activeType) {
      case 'chat':
        return mockChatHistory.filter(item => 
          item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
          item.preview.toLowerCase().includes(searchTerm.toLowerCase())
        );
      case 'image':
        return mockImageHistory.filter(item => 
          item.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
      case 'video':
        return mockVideoHistory.filter(item => 
          item.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
      default:
        return [];
    }
  };
  
  // 处理项目选择
  const handleSelectItem = (item: any) => {
    setSelectedItem(item);
  };
  
  // 处理删除项目
  const handleDeleteItem = (id: string) => {
    // 实际应用中应该调用API删除项目
    console.log('Delete item:', id);
    setSelectedItem(null);
  };
  
  // 渲染详情视图
  const renderDetailView = () => {
    if (!selectedItem) return null;
    
    switch (activeType) {
      case 'chat':
        return (
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">{selectedItem.title}</h2>
              <span className="text-sm text-gray-400">{selectedItem.date}</span>
            </div>
            <p className="text-gray-300 mb-6">{selectedItem.preview}</p>
            <div className="flex space-x-3">
              <button className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 rounded-lg text-sm text-white transition-colors">
                继续对话
              </button>
              <button 
                className="px-3 py-2 bg-red-600/30 hover:bg-red-600/50 rounded-lg text-sm text-white transition-colors"
                onClick={() => handleDeleteItem(selectedItem.id)}
              >
                删除对话
              </button>
            </div>
          </div>
        );
      case 'image':
        return (
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">{selectedItem.title}</h2>
              <span className="text-sm text-gray-400">{selectedItem.date}</span>
            </div>
            <div className="mb-6 rounded-lg overflow-hidden">
              <img src={selectedItem.url} alt={selectedItem.title} className="w-full h-auto" />
            </div>
            <div className="flex space-x-3">
              <button className="px-3 py-2 bg-green-600 hover:bg-green-500 rounded-lg text-sm text-white transition-colors">
                下载图片
              </button>
              <button className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 rounded-lg text-sm text-white transition-colors">
                分享图片
              </button>
              <button 
                className="px-3 py-2 bg-red-600/30 hover:bg-red-600/50 rounded-lg text-sm text-white transition-colors"
                onClick={() => handleDeleteItem(selectedItem.id)}
              >
                删除图片
              </button>
            </div>
          </div>
        );
      case 'video':
        return (
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">{selectedItem.title}</h2>
              <span className="text-sm text-gray-400">{selectedItem.date}</span>
            </div>
            <div className="mb-6 rounded-lg overflow-hidden">
              <video 
                src={selectedItem.url} 
                controls 
                className="w-full h-auto"
                poster={selectedItem.thumbnail}
              />
            </div>
            <div className="flex space-x-3">
              <button className="px-3 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-sm text-white transition-colors">
                下载视频
              </button>
              <button className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 rounded-lg text-sm text-white transition-colors">
                分享视频
              </button>
              <button 
                className="px-3 py-2 bg-red-600/30 hover:bg-red-600/50 rounded-lg text-sm text-white transition-colors"
                onClick={() => handleDeleteItem(selectedItem.id)}
              >
                删除视频
              </button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="flex flex-col h-screen max-h-screen">
      {/* 页面头部 */}
      <div className="p-4 border-b border-gray-800 bg-gray-900/50">
        <h1 className="text-xl font-bold text-white">创作管理</h1>
        <p className="text-gray-400 text-sm">管理您的AI创作内容</p>
      </div>
      
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧列表 */}
        <div className="w-full md:w-1/3 lg:w-1/4 border-r border-gray-800 flex flex-col">
          {/* 类型选择和搜索 */}
          <div className="p-4 border-b border-gray-800">
            <div className="flex space-x-2 mb-4">
              <button
                className={`px-3 py-1 rounded-lg text-sm ${
                  activeType === 'chat'
                    ? 'bg-cyan-600 text-white'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                } transition-colors`}
                onClick={() => setActiveType('chat')}
              >
                对话
              </button>
              <button
                className={`px-3 py-1 rounded-lg text-sm ${
                  activeType === 'image'
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                } transition-colors`}
                onClick={() => setActiveType('image')}
              >
                图片
              </button>
              <button
                className={`px-3 py-1 rounded-lg text-sm ${
                  activeType === 'video'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                } transition-colors`}
                onClick={() => setActiveType('video')}
              >
                视频
              </button>
            </div>
            
            <div className="relative">
              <input
                type="text"
                className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg pl-10 pr-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                placeholder="搜索..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
          </div>
          
          {/* 项目列表 */}
          <div className="flex-1 overflow-y-auto">
            {getDataByType().length > 0 ? (
              getDataByType().map((item) => {
                switch (activeType) {
                  case 'chat':
                    return (
                      <ChatHistoryItem
                        key={item.id}
                        item={item}
                        onSelect={() => handleSelectItem(item)}
                      />
                    );
                  case 'image':
                    return (
                      <ImageHistoryItem
                        key={item.id}
                        item={item}
                        onSelect={() => handleSelectItem(item)}
                      />
                    );
                  case 'video':
                    return (
                      <VideoHistoryItem
                        key={item.id}
                        item={item}
                        onSelect={() => handleSelectItem(item)}
                      />
                    );
                  default:
                    return null;
                }
              })
            ) : (
              <div className="p-6 text-center text-gray-500">
                {searchTerm ? '没有找到匹配的结果' : '暂无内容'}
              </div>
            )}
          </div>
        </div>
        
        {/* 右侧详情 */}
        <div className="hidden md:block md:w-2/3 lg:w-3/4 bg-gray-900/30">
          {selectedItem ? (
            renderDetailView()
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500">
              选择一个项目查看详情
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreationManagement;
