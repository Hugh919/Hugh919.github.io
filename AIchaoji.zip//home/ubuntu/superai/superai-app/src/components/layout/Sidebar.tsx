import React from 'react';
import Link from 'next/link';

// 图标组件
const HomeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

const ChatIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
  </svg>
);

const ImageIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
);

const VideoIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const UserIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);

const LoginIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
  </svg>
);

const Sidebar = () => {
  return (
    <div className="h-screen w-16 md:w-64 flex flex-col bg-black text-white border-r border-gray-800">
      {/* 顶部Logo */}
      <div className="p-4 flex items-center justify-center md:justify-start">
        <span className="text-cyan-400 font-bold text-xl hidden md:block">超级AI</span>
        <span className="text-cyan-400 font-bold text-xl md:hidden">AI</span>
      </div>
      
      {/* 导航菜单 */}
      <nav className="flex-1 px-2 py-4 space-y-2">
        <Link href="/" className="flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors group">
          <HomeIcon />
          <span className="ml-3 hidden md:block">首页</span>
        </Link>
        
        <Link href="/chat" className="flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors group">
          <ChatIcon />
          <span className="ml-3 hidden md:block">AI对话</span>
        </Link>
        
        <Link href="/image" className="flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors group">
          <ImageIcon />
          <span className="ml-3 hidden md:block">AI绘画</span>
        </Link>
        
        <Link href="/video" className="flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors group">
          <VideoIcon />
          <span className="ml-3 hidden md:block">AI视频</span>
        </Link>
        
        <Link href="/profile" className="flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors group">
          <UserIcon />
          <span className="ml-3 hidden md:block">个人信息</span>
        </Link>
      </nav>
      
      {/* 底部登录按钮 */}
      <div className="p-4 mt-auto">
        <Link href="/login" className="flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors group">
          <LoginIcon />
          <span className="ml-3 hidden md:block">登录</span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
