import React from 'react';

// 图标组件
const HistoryIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const CreationManagementSidebar = () => {
  return (
    <div className="h-screen w-16 md:w-64 flex flex-col bg-gray-900 text-white border-l border-gray-800">
      {/* 顶部标题 */}
      <div className="p-4 flex items-center justify-center md:justify-start">
        <span className="text-cyan-400 font-bold text-lg hidden md:block">创作管理</span>
        <span className="text-cyan-400 font-bold text-lg md:hidden">管理</span>
      </div>
      
      {/* 创作历史分类 */}
      <div className="flex-1 px-2 py-4 space-y-6">
        {/* 对话历史 */}
        <div className="space-y-2">
          <div className="flex items-center p-2 text-cyan-400">
            <HistoryIcon />
            <span className="ml-3 hidden md:block font-medium">对话历史</span>
          </div>
          <div className="space-y-1 pl-2">
            {[1, 2, 3].map((item) => (
              <button key={`chat-${item}`} className="w-full flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors text-left text-sm">
                <span className="w-2 h-2 rounded-full bg-cyan-400 mr-2"></span>
                <span className="hidden md:block truncate">对话记录 {item}</span>
              </button>
            ))}
          </div>
        </div>
        
        {/* 图片历史 */}
        <div className="space-y-2">
          <div className="flex items-center p-2 text-green-400">
            <HistoryIcon />
            <span className="ml-3 hidden md:block font-medium">图片历史</span>
          </div>
          <div className="space-y-1 pl-2">
            {[1, 2, 3].map((item) => (
              <button key={`image-${item}`} className="w-full flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors text-left text-sm">
                <span className="w-2 h-2 rounded-full bg-green-400 mr-2"></span>
                <span className="hidden md:block truncate">图片作品 {item}</span>
              </button>
            ))}
          </div>
        </div>
        
        {/* 视频历史 */}
        <div className="space-y-2">
          <div className="flex items-center p-2 text-purple-400">
            <HistoryIcon />
            <span className="ml-3 hidden md:block font-medium">视频历史</span>
          </div>
          <div className="space-y-1 pl-2">
            {[1, 2, 3].map((item) => (
              <button key={`video-${item}`} className="w-full flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors text-left text-sm">
                <span className="w-2 h-2 rounded-full bg-purple-400 mr-2"></span>
                <span className="hidden md:block truncate">视频作品 {item}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* 底部存储信息 */}
      <div className="p-4 bg-gray-950 text-xs text-gray-400 hidden md:block">
        <div className="flex justify-between mb-1">
          <span>存储空间</span>
          <span>30%</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2">
          <div className="bg-cyan-400 h-2 rounded-full" style={{ width: '30%' }}></div>
        </div>
      </div>
    </div>
  );
};

export default CreationManagementSidebar;
