import React from 'react';

interface MainContentProps {
  children: React.ReactNode;
}

const MainContent: React.FC<MainContentProps> = ({ children }) => {
  return (
    <div className="flex-1 overflow-auto bg-gradient-to-br from-gray-900 to-black">
      <div className="container mx-auto p-6">
        {/* 科技感装饰元素 */}
        <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-cyan-500/5 blur-3xl rounded-full"></div>
        <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-blue-500/5 blur-3xl rounded-full"></div>
        
        {/* 网格背景 - 增加科技感 */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        
        {/* 主要内容区域 */}
        <div className="relative z-10">
          {children}
        </div>
      </div>
    </div>
  );
};

export default MainContent;
