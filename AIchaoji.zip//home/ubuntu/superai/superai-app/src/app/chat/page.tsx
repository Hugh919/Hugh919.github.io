'use client';

import React, { useState, useRef, useEffect } from 'react';

// 消息类型定义
type MessageType = {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
};

// 模拟与Deepseek API交互的函数
const fetchDeepseekResponse = async (message: string): Promise<string> => {
  // 这里是模拟API调用，实际实现时需要替换为真实的Deepseek API调用
  console.log('Sending to Deepseek API:', message);
  
  // 模拟API延迟
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // 模拟不同的回复
  const responses = [
    "我是基于Deepseek的AI助手，很高兴能帮助到您。您有什么具体问题需要解答吗？",
    "根据您的问题，我建议您可以考虑以下几个方面...",
    "这是一个很好的问题。从技术角度来看，有几种可能的解决方案...",
    "我理解您的需求。基于您提供的信息，我认为最佳方案是...",
    "感谢您的提问。这个问题涉及多个领域，让我为您详细分析一下..."
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
};

const ChatPage = () => {
  const [messages, setMessages] = useState<MessageType[]>([
    {
      id: '1',
      content: '你好！我是超级AI的智能助手，基于Deepseek强大的语言模型。我可以回答问题、提供建议、协助创作，请告诉我您需要什么帮助？',
      role: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // 自动滚动到最新消息
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  // 发送消息
  const handleSendMessage = async () => {
    if (inputMessage.trim() === '') return;
    
    // 添加用户消息
    const userMessage: MessageType = {
      id: Date.now().toString(),
      content: inputMessage,
      role: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);
    
    try {
      // 调用Deepseek API获取回复
      const response = await fetchDeepseekResponse(inputMessage);
      
      // 添加AI回复
      const assistantMessage: MessageType = {
        id: (Date.now() + 1).toString(),
        content: response,
        role: 'assistant',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error fetching response:', error);
      
      // 添加错误消息
      const errorMessage: MessageType = {
        id: (Date.now() + 1).toString(),
        content: '抱歉，我遇到了一些问题，无法回应您的请求。请稍后再试。',
        role: 'assistant',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // 处理按键事件（回车发送消息）
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  return (
    <div className="flex flex-col h-screen max-h-screen">
      {/* 聊天头部 */}
      <div className="p-4 border-b border-gray-800 bg-gray-900/50">
        <h1 className="text-xl font-bold text-white">AI对话</h1>
        <p className="text-gray-400 text-sm">基于Deepseek强大的语言模型</p>
      </div>
      
      {/* 聊天消息区域 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-4 ${
                message.role === 'user'
                  ? 'bg-cyan-600 text-white'
                  : 'bg-gray-800 text-white'
              }`}
            >
              <div className="whitespace-pre-wrap">{message.content}</div>
              <div className={`text-xs mt-2 ${
                message.role === 'user' ? 'text-cyan-200' : 'text-gray-400'
              }`}>
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        
        {/* 加载指示器 */}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-800 text-white rounded-lg p-4 flex items-center space-x-2">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse delay-150"></div>
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse delay-300"></div>
            </div>
          </div>
        )}
        
        {/* 用于自动滚动的引用元素 */}
        <div ref={messagesEndRef} />
      </div>
      
      {/* 输入区域 */}
      <div className="p-4 border-t border-gray-800 bg-gray-900/50">
        <div className="flex items-center space-x-2">
          <textarea
            className="flex-1 bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
            placeholder="输入您的问题或请求..."
            rows={2}
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <button
            className={`p-3 rounded-lg ${
              inputMessage.trim() === '' || isLoading
                ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:shadow-lg hover:shadow-cyan-500/20'
            } transition-all`}
            onClick={handleSendMessage}
            disabled={inputMessage.trim() === '' || isLoading}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"
              />
            </svg>
          </button>
        </div>
        <div className="mt-2 text-xs text-gray-500 flex justify-between items-center">
          <span>按Enter发送，Shift+Enter换行</span>
          <span>由Deepseek提供支持</span>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
