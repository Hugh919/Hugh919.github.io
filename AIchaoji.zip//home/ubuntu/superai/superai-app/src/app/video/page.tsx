'use client';

import React, { useState, useRef } from 'react';

// 视频生成风格选项
const styleOptions = [
  { id: 'cinematic', name: '电影风格', description: '高质量电影级视觉效果' },
  { id: 'animation', name: '动画风格', description: '3D动画效果' },
  { id: 'vlog', name: 'Vlog风格', description: '日常生活记录风格' },
  { id: 'commercial', name: '商业广告', description: '专业商业宣传效果' },
  { id: 'scifi', name: '科幻风格', description: '未来科技视觉效果' },
  { id: 'vintage', name: '复古风格', description: '怀旧复古滤镜效果' },
];

// 视频时长选项
const durationOptions = [
  { id: '15s', name: '15秒', description: '短视频' },
  { id: '30s', name: '30秒', description: '标准长度' },
  { id: '60s', name: '60秒', description: '完整视频' },
];

// 模拟与可灵API交互的函数
const fetchKeliVideoGeneration = async (prompt: string, style: string, duration: string): Promise<string> => {
  // 这里是模拟API调用，实际实现时需要替换为真实的可灵API调用
  console.log('Sending to Keli API:', { prompt, style, duration });
  
  // 模拟API延迟
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  // 模拟返回的视频URL（实际应该是从API返回的视频URL）
  // 这里使用一些示例视频URL
  const videoUrls = [
    'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
  ];
  
  // 使用prompt的哈希值作为随机种子，确保相同的prompt生成相同的"视频"
  const seed = prompt.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const index = seed % videoUrls.length;
  
  return videoUrls[index];
};

const VideoGenerationPage = () => {
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('cinematic');
  const [selectedDuration, setSelectedDuration] = useState('30s');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedVideos, setGeneratedVideos] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const promptRef = useRef<HTMLTextAreaElement>(null);
  
  // 生成视频
  const handleGenerateVideo = async () => {
    if (prompt.trim() === '') {
      setError('请输入视频描述');
      promptRef.current?.focus();
      return;
    }
    
    setError(null);
    setIsGenerating(true);
    
    try {
      // 调用可灵API生成视频
      const videoUrl = await fetchKeliVideoGeneration(prompt, selectedStyle, selectedDuration);
      
      // 添加到生成的视频列表
      setGeneratedVideos(prev => [videoUrl, ...prev]);
    } catch (error) {
      console.error('Error generating video:', error);
      setError('视频生成失败，请稍后再试');
    } finally {
      setIsGenerating(false);
    }
  };
  
  // 保存视频
  const handleSaveVideo = (videoUrl: string) => {
    // 在实际应用中，这里应该实现保存视频到用户账户的功能
    console.log('Saving video:', videoUrl);
    alert('视频已保存到您的创作管理中');
  };
  
  // 下载视频
  const handleDownloadVideo = (videoUrl: string) => {
    // 在实际应用中，这里应该实现下载视频的功能
    console.log('Downloading video:', videoUrl);
    
    // 创建一个临时链接并触发下载
    const link = document.createElement('a');
    link.href = videoUrl;
    link.download = `superai-video-${Date.now()}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div className="flex flex-col h-screen max-h-screen">
      {/* 页面头部 */}
      <div className="p-4 border-b border-gray-800 bg-gray-900/50">
        <h1 className="text-xl font-bold text-white">AI视频</h1>
        <p className="text-gray-400 text-sm">基于可灵AI的视频生成技术</p>
      </div>
      
      <div className="flex-1 overflow-auto">
        <div className="container mx-auto p-4">
          {/* 视频生成控制面板 */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 mb-8">
            <h2 className="text-xl font-bold mb-4 text-white">创建新视频</h2>
            
            {/* 提示词输入 */}
            <div className="mb-6">
              <label htmlFor="prompt" className="block text-sm font-medium text-gray-400 mb-2">
                视频描述
              </label>
              <textarea
                ref={promptRef}
                id="prompt"
                rows={3}
                className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                placeholder="描述您想要生成的视频内容，例如：一只猫在宇宙飞船中漂浮，穿着宇航服，周围有星星和行星..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              {error && <p className="mt-2 text-red-500 text-sm">{error}</p>}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* 风格选择 */}
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  视频风格
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {styleOptions.map((style) => (
                    <button
                      key={style.id}
                      className={`p-3 rounded-lg text-left ${
                        selectedStyle === style.id
                          ? 'bg-purple-600/20 border border-purple-500'
                          : 'bg-gray-800 border border-gray-700 hover:border-gray-600'
                      } transition-all`}
                      onClick={() => setSelectedStyle(style.id)}
                    >
                      <div className="font-medium text-white">{style.name}</div>
                      <div className="text-xs text-gray-400">{style.description}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* 时长选择 */}
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  视频时长
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {durationOptions.map((duration) => (
                    <button
                      key={duration.id}
                      className={`p-3 rounded-lg text-left ${
                        selectedDuration === duration.id
                          ? 'bg-purple-600/20 border border-purple-500'
                          : 'bg-gray-800 border border-gray-700 hover:border-gray-600'
                      } transition-all`}
                      onClick={() => setSelectedDuration(duration.id)}
                    >
                      <div className="font-medium text-white">{duration.name}</div>
                      <div className="text-xs text-gray-400">{duration.description}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* 生成按钮 */}
            <button
              className={`w-full py-3 rounded-lg font-medium ${
                isGenerating
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white hover:shadow-lg hover:shadow-purple-500/20'
              } transition-all`}
              onClick={handleGenerateVideo}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-150"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-300"></div>
                  <span className="ml-2">生成中...</span>
                </div>
              ) : (
                '生成视频'
              )}
            </button>
          </div>
          
          {/* 生成的视频展示 */}
          {generatedVideos.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-4 text-white">生成的视频</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {generatedVideos.map((videoUrl, index) => (
                  <div key={index} className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 overflow-hidden">
                    <div className="aspect-video">
                      <video
                        src={videoUrl}
                        controls
                        className="w-full h-full object-cover"
                        poster="/video-placeholder.jpg"
                      />
                    </div>
                    <div className="p-4 flex justify-between">
                      <button
                        className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm text-white transition-colors"
                        onClick={() => handleSaveVideo(videoUrl)}
                      >
                        保存
                      </button>
                      <button
                        className="px-3 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-sm text-white transition-colors"
                        onClick={() => handleDownloadVideo(videoUrl)}
                      >
                        下载
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* 提示词建议 */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6">
            <h2 className="text-xl font-bold mb-4 text-white">提示词建议</h2>
            <div className="space-y-4">
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="font-medium text-purple-400 mb-2">自然风景</h3>
                <p className="text-gray-300 text-sm">
                  航拍视角，壮观的山脉和瀑布，阳光透过云层照射，鸟儿飞过，电影风格，4K高清
                </p>
              </div>
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="font-medium text-purple-400 mb-2">科技展示</h3>
                <p className="text-gray-300 text-sm">
                  未来科技城市，飞行汽车穿梭，全息投影广告，霓虹灯闪烁，人们使用先进科技设备，科幻风格
                </p>
              </div>
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="font-medium text-purple-400 mb-2">产品展示</h3>
                <p className="text-gray-300 text-sm">
                  时尚的智能手表在旋转展台上展示，特写镜头展示细节，背景虚化，商业广告风格，明亮照明
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoGenerationPage;
