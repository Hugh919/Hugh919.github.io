import React from 'react';

// 图标组件
const ChatBotIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
  </svg>
);

const ImageIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
);

const VideoIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const HomePage = () => {
  return (
    <div className="min-h-screen">
      {/* 英雄区域 */}
      <section className="relative py-20 overflow-hidden">
        {/* 科技感背景元素 */}
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-10 left-10 w-32 h-32 bg-cyan-500/20 rounded-full blur-xl"></div>
          <div className="absolute bottom-10 right-10 w-40 h-40 bg-purple-500/20 rounded-full blur-xl"></div>
          <div className="absolute top-1/3 right-1/4 w-24 h-24 bg-blue-500/20 rounded-full blur-xl"></div>
        </div>
        
        {/* 动态线条背景 - 增强科技感 */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute left-1/4 top-0 h-full w-px bg-gradient-to-b from-transparent via-cyan-500 to-transparent"></div>
          <div className="absolute left-2/4 top-0 h-full w-px bg-gradient-to-b from-transparent via-cyan-500 to-transparent"></div>
          <div className="absolute left-3/4 top-0 h-full w-px bg-gradient-to-b from-transparent via-cyan-500 to-transparent"></div>
          
          <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>
          <div className="absolute top-2/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>
          <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
            超级AI
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-10 max-w-3xl mx-auto">
            一站式AI创作平台，让您的创意无限可能
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full text-white font-medium hover:shadow-lg hover:shadow-cyan-500/20 transition-all">
              立即体验
            </button>
            <button className="px-8 py-3 bg-gray-800 border border-gray-700 rounded-full text-white font-medium hover:bg-gray-700 transition-all">
              了解更多
            </button>
          </div>
        </div>
      </section>
      
      {/* 工具介绍区域 */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">强大功能</span>
            <span className="ml-2 text-white">一站式解决方案</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* AI对话 */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-gray-800 hover:border-cyan-500/50 transition-all group">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center mb-6 group-hover:shadow-lg group-hover:shadow-cyan-500/20 transition-all">
                <ChatBotIcon />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-white">AI对话</h3>
              <p className="text-gray-400 mb-6">
                基于DeepSeek强大的语言模型，提供智能对话服务，帮助您解答问题、创作内容、提供建议，让AI成为您的得力助手。
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 mr-2"></span>
                  智能问答与内容创作
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 mr-2"></span>
                  多轮对话记忆能力
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 mr-2"></span>
                  专业领域知识支持
                </li>
              </ul>
            </div>
            
            {/* AI绘画 */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-gray-800 hover:border-green-500/50 transition-all group">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-teal-600 flex items-center justify-center mb-6 group-hover:shadow-lg group-hover:shadow-green-500/20 transition-all">
                <ImageIcon />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-white">AI绘画</h3>
              <p className="text-gray-400 mb-6">
                接入可灵AI绘画引擎，通过文本描述生成精美图像，满足您的创意需求，让想象力变为现实。
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-green-400 mr-2"></span>
                  文本转图像生成
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-green-400 mr-2"></span>
                  多种艺术风格选择
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-green-400 mr-2"></span>
                  高清图像导出与分享
                </li>
              </ul>
            </div>
            
            {/* AI视频 */}
            <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-gray-800 hover:border-purple-500/50 transition-all group">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center mb-6 group-hover:shadow-lg group-hover:shadow-purple-500/20 transition-all">
                <VideoIcon />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-white">AI视频</h3>
              <p className="text-gray-400 mb-6">
                基于可灵AI视频技术，轻松创建高质量视频内容，从文本描述到精彩视频，简单高效。
              </p>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-purple-400 mr-2"></span>
                  文本生成视频内容
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-purple-400 mr-2"></span>
                  多种视频风格与场景
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-purple-400 mr-2"></span>
                  视频编辑与导出功能
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* 技术优势 */}
      <section className="py-20 relative bg-gradient-to-b from-transparent to-gray-900/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">技术优势</span>
            <span className="ml-2 text-white">领先AI体验</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* 优势1 */}
            <div className="bg-gray-900/30 backdrop-blur-sm p-6 rounded-xl border border-gray-800">
              <div className="text-cyan-400 text-5xl font-bold mb-4">01</div>
              <h3 className="text-xl font-bold mb-2 text-white">顶尖AI模型</h3>
              <p className="text-gray-400">
                接入业界领先的DeepSeek和可灵AI模型，提供最先进的AI能力支持。
              </p>
            </div>
            
            {/* 优势2 */}
            <div className="bg-gray-900/30 backdrop-blur-sm p-6 rounded-xl border border-gray-800">
              <div className="text-cyan-400 text-5xl font-bold mb-4">02</div>
              <h3 className="text-xl font-bold mb-2 text-white">一站式平台</h3>
              <p className="text-gray-400">
                集成对话、绘画、视频等多种AI功能，满足您的全方位创作需求。
              </p>
            </div>
            
            {/* 优势3 */}
            <div className="bg-gray-900/30 backdrop-blur-sm p-6 rounded-xl border border-gray-800">
              <div className="text-cyan-400 text-5xl font-bold mb-4">03</div>
              <h3 className="text-xl font-bold mb-2 text-white">高效创作</h3>
              <p className="text-gray-400">
                简洁直观的操作界面，让您快速上手，高效完成创作任务。
              </p>
            </div>
            
            {/* 优势4 */}
            <div className="bg-gray-900/30 backdrop-blur-sm p-6 rounded-xl border border-gray-800">
              <div className="text-cyan-400 text-5xl font-bold mb-4">04</div>
              <h3 className="text-xl font-bold mb-2 text-white">作品管理</h3>
              <p className="text-gray-400">
                智能管理您的创作历史，随时查看、编辑和分享您的AI创作成果。
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* 开始使用 */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="bg-gradient-to-r from-gray-900 to-gray-800 p-12 rounded-3xl border border-gray-700 relative overflow-hidden">
            {/* 科技感装饰 */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
            
            <h2 className="text-3xl md:text-4xl font-bold mb-6 relative z-10">
              准备好开启AI创作之旅了吗？
            </h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto relative z-10">
              立即注册超级AI平台，探索无限创意可能，让AI成为您的创作伙伴。
            </p>
            <button className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full text-white font-medium text-lg hover:shadow-lg hover:shadow-cyan-500/20 transition-all relative z-10">
              立即开始
            </button>
          </div>
        </div>
      </section>
      
      {/* 页脚 */}
      <footer className="py-10 border-t border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <span className="text-2xl font-bold text-cyan-400">超级AI</span>
              <p className="text-gray-500 mt-2">一站式AI创作平台</p>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">关于我们</a>
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">使用条款</a>
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">隐私政策</a>
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">联系我们</a>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-500 text-sm">
            © 2025 超级AI. 保留所有权利.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
