'use client';

import React, { useState, useRef } from 'react';

// 图像生成风格选项
const styleOptions = [
  { id: 'realistic', name: '写实风格', description: '逼真的照片级效果' },
  { id: 'anime', name: '动漫风格', description: '日式动漫插画风格' },
  { id: 'oil', name: '油画风格', description: '传统油画艺术效果' },
  { id: 'watercolor', name: '水彩风格', description: '柔和的水彩画效果' },
  { id: 'sketch', name: '素描风格', description: '黑白素描艺术效果' },
  { id: 'digital', name: '数字艺术', description: '现代数字艺术风格' },
];

// 图像比例选项
const aspectRatioOptions = [
  { id: '1:1', name: '1:1', description: '方形' },
  { id: '4:3', name: '4:3', description: '标准' },
  { id: '16:9', name: '16:9', description: '宽屏' },
  { id: '9:16', name: '9:16', description: '竖屏' },
];

// 模拟与可灵API交互的函数
const fetchKeliImageGeneration = async (prompt: string, style: string, aspectRatio: string): Promise<string> => {
  // 这里是模拟API调用，实际实现时需要替换为真实的可灵API调用
  console.log('Sending to Keli API:', { prompt, style, aspectRatio });
  
  // 模拟API延迟
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // 模拟返回的图片URL（实际应该是从API返回的图片URL）
  // 这里使用占位图片服务生成不同的图片
  const width = aspectRatio === '1:1' ? 512 : aspectRatio === '16:9' ? 640 : aspectRatio === '9:16' ? 384 : 512;
  const height = aspectRatio === '1:1' ? 512 : aspectRatio === '16:9' ? 360 : aspectRatio === '9:16' ? 640 : 384;
  
  // 使用prompt的哈希值作为随机种子，确保相同的prompt生成相同的"图片"
  const seed = prompt.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  
  return `https://picsum.photos/seed/${seed}/${width}/${height}`;
};

const ImageGenerationPage = () => {
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [selectedAspectRatio, setSelectedAspectRatio] = useState('1:1');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const promptRef = useRef<HTMLTextAreaElement>(null);
  
  // 生成图像
  const handleGenerateImage = async () => {
    if (prompt.trim() === '') {
      setError('请输入图像描述');
      promptRef.current?.focus();
      return;
    }
    
    setError(null);
    setIsGenerating(true);
    
    try {
      // 调用可灵API生成图像
      const imageUrl = await fetchKeliImageGeneration(prompt, selectedStyle, selectedAspectRatio);
      
      // 添加到生成的图像列表
      setGeneratedImages(prev => [imageUrl, ...prev]);
    } catch (error) {
      console.error('Error generating image:', error);
      setError('图像生成失败，请稍后再试');
    } finally {
      setIsGenerating(false);
    }
  };
  
  // 保存图像
  const handleSaveImage = (imageUrl: string) => {
    // 在实际应用中，这里应该实现保存图像到用户账户的功能
    console.log('Saving image:', imageUrl);
    alert('图像已保存到您的创作管理中');
  };
  
  // 下载图像
  const handleDownloadImage = (imageUrl: string) => {
    // 在实际应用中，这里应该实现下载图像的功能
    console.log('Downloading image:', imageUrl);
    
    // 创建一个临时链接并触发下载
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `superai-image-${Date.now()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div className="flex flex-col h-screen max-h-screen">
      {/* 页面头部 */}
      <div className="p-4 border-b border-gray-800 bg-gray-900/50">
        <h1 className="text-xl font-bold text-white">AI绘画</h1>
        <p className="text-gray-400 text-sm">基于可灵AI的图像生成技术</p>
      </div>
      
      <div className="flex-1 overflow-auto">
        <div className="container mx-auto p-4">
          {/* 图像生成控制面板 */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 mb-8">
            <h2 className="text-xl font-bold mb-4 text-white">创建新图像</h2>
            
            {/* 提示词输入 */}
            <div className="mb-6">
              <label htmlFor="prompt" className="block text-sm font-medium text-gray-400 mb-2">
                图像描述
              </label>
              <textarea
                ref={promptRef}
                id="prompt"
                rows={3}
                className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
                placeholder="描述您想要生成的图像，例如：一只在星空下奔跑的狼，背景是满月和星星..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              {error && <p className="mt-2 text-red-500 text-sm">{error}</p>}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* 风格选择 */}
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  图像风格
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {styleOptions.map((style) => (
                    <button
                      key={style.id}
                      className={`p-3 rounded-lg text-left ${
                        selectedStyle === style.id
                          ? 'bg-green-600/20 border border-green-500'
                          : 'bg-gray-800 border border-gray-700 hover:border-gray-600'
                      } transition-all`}
                      onClick={() => setSelectedStyle(style.id)}
                    >
                      <div className="font-medium text-white">{style.name}</div>
                      <div className="text-xs text-gray-400">{style.description}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* 比例选择 */}
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  图像比例
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {aspectRatioOptions.map((ratio) => (
                    <button
                      key={ratio.id}
                      className={`p-3 rounded-lg text-left ${
                        selectedAspectRatio === ratio.id
                          ? 'bg-green-600/20 border border-green-500'
                          : 'bg-gray-800 border border-gray-700 hover:border-gray-600'
                      } transition-all`}
                      onClick={() => setSelectedAspectRatio(ratio.id)}
                    >
                      <div className="font-medium text-white">{ratio.name}</div>
                      <div className="text-xs text-gray-400">{ratio.description}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* 生成按钮 */}
            <button
              className={`w-full py-3 rounded-lg font-medium ${
                isGenerating
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-green-500 to-teal-600 text-white hover:shadow-lg hover:shadow-green-500/20'
              } transition-all`}
              onClick={handleGenerateImage}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-150"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-300"></div>
                  <span className="ml-2">生成中...</span>
                </div>
              ) : (
                '生成图像'
              )}
            </button>
          </div>
          
          {/* 生成的图像展示 */}
          {generatedImages.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-4 text-white">生成的图像</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {generatedImages.map((imageUrl, index) => (
                  <div key={index} className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 overflow-hidden group">
                    <div className="relative aspect-square md:aspect-auto md:h-64 overflow-hidden">
                      <img
                        src={imageUrl}
                        alt={`Generated image ${index + 1}`}
                        className="w-full h-full object-cover transition-transform group-hover:scale-105"
                      />
                    </div>
                    <div className="p-4 flex justify-between">
                      <button
                        className="px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm text-white transition-colors"
                        onClick={() => handleSaveImage(imageUrl)}
                      >
                        保存
                      </button>
                      <button
                        className="px-3 py-2 bg-green-600 hover:bg-green-500 rounded-lg text-sm text-white transition-colors"
                        onClick={() => handleDownloadImage(imageUrl)}
                      >
                        下载
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* 提示词建议 */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6">
            <h2 className="text-xl font-bold mb-4 text-white">提示词建议</h2>
            <div className="space-y-4">
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="font-medium text-green-400 mb-2">风景描述</h3>
                <p className="text-gray-300 text-sm">
                  一片宁静的湖泊，周围环绕着雪山，天空中有北极光，星空璀璨，8K超高清，写实风格
                </p>
              </div>
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="font-medium text-green-400 mb-2">人物描述</h3>
                <p className="text-gray-300 text-sm">
                  一位身穿未来科技盔甲的女战士，站在霓虹灯闪烁的赛博朋克城市中，背景有飞行汽车，高细节，电影感
                </p>
              </div>
              <div className="p-4 bg-gray-800 rounded-lg">
                <h3 className="font-medium text-green-400 mb-2">抽象艺术</h3>
                <p className="text-gray-300 text-sm">
                  表现情绪"希望"的抽象画，使用明亮的蓝色和金色，流动的线条，如同光线穿过黑暗，油画风格
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageGenerationPage;
