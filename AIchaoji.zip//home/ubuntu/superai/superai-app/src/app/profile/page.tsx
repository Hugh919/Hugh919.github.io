'use client';

import React, { useState } from 'react';

// 模拟用户数据
const mockUserData = {
  id: '12345',
  name: '张三',
  email: 'zhangsan@example.com',
  avatar: 'https://i.pravatar.cc/300',
  createdAt: '2023-01-15',
  plan: '高级会员',
  usageStats: {
    chatCount: 128,
    imageCount: 45,
    videoCount: 12,
    storageUsed: '2.4GB',
    storageLimit: '10GB',
  }
};

const ProfilePage = () => {
  const [user, setUser] = useState(mockUserData);
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // 处理个人信息更新
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !email) {
      setError('请填写所有必填字段');
      return;
    }
    
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    
    try {
      // 模拟API调用
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 模拟更新成功，实际应用中应该调用真实的API
      console.log('Update profile:', { name, email });
      
      // 更新本地状态
      setUser(prev => ({ ...prev, name, email }));
      setIsEditing(false);
      setSuccess('个人信息更新成功');
    } catch (error) {
      console.error('Update profile error:', error);
      setError('更新失败，请稍后再试');
    } finally {
      setIsLoading(false);
    }
  };

  // 处理密码更新
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      setError('请填写所有密码字段');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      setError('两次输入的新密码不一致');
      return;
    }
    
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    
    try {
      // 模拟API调用
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 模拟更新成功，实际应用中应该调用真实的API
      console.log('Update password:', { currentPassword, newPassword });
      
      // 清空密码字段
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setSuccess('密码更新成功');
    } catch (error) {
      console.error('Update password error:', error);
      setError('密码更新失败，请确认当前密码是否正确');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen max-h-screen">
      {/* 页面头部 */}
      <div className="p-4 border-b border-gray-800 bg-gray-900/50">
        <h1 className="text-xl font-bold text-white">个人信息</h1>
        <p className="text-gray-400 text-sm">管理您的账户和设置</p>
      </div>
      
      <div className="flex-1 overflow-auto">
        <div className="container mx-auto p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* 左侧个人信息卡片 */}
            <div className="md:col-span-1">
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6">
                <div className="flex flex-col items-center">
                  <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-2 border-cyan-500">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h2 className="text-xl font-bold text-white mb-1">{user.name}</h2>
                  <p className="text-gray-400 text-sm mb-4">{user.email}</p>
                  <div className="px-3 py-1 bg-cyan-500/20 text-cyan-400 rounded-full text-xs font-medium mb-4">
                    {user.plan}
                  </div>
                  <p className="text-gray-500 text-xs">
                    注册时间: {user.createdAt}
                  </p>
                </div>
                
                <div className="mt-6 pt-6 border-t border-gray-800">
                  <h3 className="text-sm font-medium text-gray-400 mb-4">使用统计</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-sm">AI对话</span>
                      <span className="text-white text-sm">{user.usageStats.chatCount} 次</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-sm">AI绘画</span>
                      <span className="text-white text-sm">{user.usageStats.imageCount} 张</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-sm">AI视频</span>
                      <span className="text-white text-sm">{user.usageStats.videoCount} 个</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 text-sm">存储空间</span>
                      <span className="text-white text-sm">{user.usageStats.storageUsed} / {user.usageStats.storageLimit}</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2 mt-2">
                      <div
                        className="bg-cyan-500 h-2 rounded-full"
                        style={{
                          width: `${(parseFloat(user.usageStats.storageUsed) / parseFloat(user.usageStats.storageLimit)) * 100}%`
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* 右侧设置表单 */}
            <div className="md:col-span-2">
              {/* 成功/错误消息 */}
              {success && (
                <div className="mb-6 p-3 bg-green-900/50 border border-green-800 rounded-lg text-green-200 text-sm">
                  {success}
                </div>
              )}
              
              {error && (
                <div className="mb-6 p-3 bg-red-900/50 border border-red-800 rounded-lg text-red-200 text-sm">
                  {error}
                </div>
              )}
              
              {/* 个人信息表单 */}
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 mb-8">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold text-white">个人信息</h2>
                  <button
                    className="px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm text-white transition-colors"
                    onClick={() => setIsEditing(!isEditing)}
                  >
                    {isEditing ? '取消' : '编辑'}
                  </button>
                </div>
                
                <form onSubmit={handleUpdateProfile}>
                  <div className="mb-6">
                    <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-2">
                      用户名
                    </label>
                    {isEditing ? (
                      <input
                        id="name"
                        type="text"
                        className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    ) : (
                      <div className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3">
                        {user.name}
                      </div>
                    )}
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">
                      邮箱地址
                    </label>
                    {isEditing ? (
                      <input
                        id="email"
                        type="email"
                        className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    ) : (
                      <div className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3">
                        {user.email}
                      </div>
                    )}
                  </div>
                  
                  {isEditing && (
                    <button
                      type="submit"
                      className={`w-full py-3 rounded-lg font-medium ${
                        isLoading
                          ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                          : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:shadow-lg hover:shadow-cyan-500/20'
                      } transition-all`}
                      disabled={isLoading}
                    >
                      {isLoading ? '更新中...' : '更新信息'}
                    </button>
                  )}
                </form>
              </div>
              
              {/* 修改密码表单 */}
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6">
                <h2 className="text-xl font-bold text-white mb-6">修改密码</h2>
                
                <form onSubmit={handleUpdatePassword}>
                  <div className="mb-6">
                    <label htmlFor="current-password" className="block text-sm font-medium text-gray-400 mb-2">
                      当前密码
                    </label>
                    <input
                      id="current-password"
                      type="password"
                      className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      placeholder="••••••••"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="new-password" className="block text-sm font-medium text-gray-400 mb-2">
                      新密码
                    </label>
                    <input
                      id="new-password"
                      type="password"
                      className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      placeholder="••••••••"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-400 mb-2">
                      确认新密码
                    </label>
                    <input
                      id="confirm-password"
                      type="password"
                      className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                  </div>
                  
                  <button
                    type="submit"
                    className={`w-full py-3 rounded-lg font-medium ${
                      isLoading
                        ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:shadow-lg hover:shadow-cyan-500/20'
                    } transition-all`}
                    disabled={isLoading}
                  >
                    {isLoading ? '更新中...' : '更新密码'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
