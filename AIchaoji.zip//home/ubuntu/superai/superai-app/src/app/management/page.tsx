'use client';

import React from 'react';
import CreationManagement from '@/components/creation-management/CreationManagement';

const ManagementPage = () => {
  return <CreationManagement />;
};

export default ManagementPage;
